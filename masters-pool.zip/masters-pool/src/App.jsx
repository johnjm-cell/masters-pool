import { useState, useEffect, useCallback } from "react";

const AUGUSTA_PAR = 72;

// ─────────────────────────────────────────────
// PICKS DATA
// ─────────────────────────────────────────────
const PARTICIPANTS = [
  {
    id: 1,
    name: "Cameron Maguire",
    golfers: [
      { name: "Cameron Young", tier: "A" },
      { name: "Bryson DeChambeau", tier: "A" },
      { name: "Brooks Koepka", tier: "B" },
      { name: "Nicolai Hojgaard", tier: "C" },
      { name: "Marco Penge", tier: "D" },
      { name: "Michael Kim", tier: "E" },
    ],
    bonusMissCut: "Russell Henley",
    bonusMakeCut: "Michael Kim",
  },
  {
    id: 2,
    name: "Stephen Shiller",
    golfers: [
      { name: "Bryson DeChambeau", tier: "A" },
      { name: "Ludvig Aberg", tier: "A" },
      { name: "Justin Rose", tier: "B" },
      { name: "Jake Knapp", tier: "C" },
      { name: "Harris English", tier: "D" },
      { name: "Nick Taylor", tier: "E" },
    ],
    bonusMissCut: "Hideki Matsuyama",
    bonusMakeCut: "Charl Schwartzel",
  },
  {
    id: 3,
    name: "Joshua Baginski",
    golfers: [
      { name: "Xander Schauffele", tier: "A" },
      { name: "Ludvig Aberg", tier: "A" },
      { name: "Justin Rose", tier: "B" },
      { name: "Adam Scott", tier: "C" },
      { name: "Cameron Smith", tier: "D" },
      { name: "Brian Harman", tier: "E" },
    ],
    bonusMissCut: "Chris Gotterup",
    bonusMakeCut: "Aaron Rai",
  },
  {
    id: 4,
    name: "Keith Smellie",
    golfers: [
      { name: "Matt Fitzpatrick", tier: "A" },
      { name: "Xander Schauffele", tier: "A" },
      { name: "Robert MacIntyre", tier: "B" },
      { name: "Akshay Bhatia", tier: "C" },
      { name: "Sungjae Im", tier: "D" },
      { name: "Sergio Garcia", tier: "E" },
    ],
    bonusMissCut: "Sam Burns",
    bonusMakeCut: "Casey Jarvis",
  },
  {
    id: 5,
    name: "J.M.",
    golfers: [
      { name: "Matt Fitzpatrick", tier: "A" },
      { name: "Bryson DeChambeau", tier: "A" },
      { name: "Patrick Reed", tier: "B" },
      { name: "Akshay Bhatia", tier: "C" },
      { name: "Daniel Berger", tier: "D" },
      { name: "Ryan Fox", tier: "E" },
    ],
    bonusMissCut: "Viktor Hovland",
    bonusMakeCut: "Nicolas Echavarria",
  },
  {
    id: 6,
    name: "David Saunders",
    golfers: [
      { name: "Scottie Scheffler", tier: "A" },
      { name: "Cameron Young", tier: "A" },
      { name: "Viktor Hovland", tier: "B" },
      { name: "Jason Day", tier: "C" },
      { name: "Marco Penge", tier: "D" },
      { name: "Nicolas Echavarria", tier: "E" },
    ],
    bonusMissCut: "Patrick Reed",
    bonusMakeCut: "Max Greyserman",
  },
  {
    id: 7,
    name: "Foyo",
    golfers: [
      { name: "Min Woo Lee", tier: "A" },
      { name: "Vijay Singh", tier: "A" },
      { name: "Hideki Matsuyama", tier: "B" },
      { name: "Sam Burns", tier: "C" },
      { name: "Max Homa", tier: "D" },
      { name: "Collin Morikawa", tier: "E" },
    ],
    bonusMissCut: null,
    bonusMakeCut: null,
  },
];

// ─────────────────────────────────────────────
// UTILITIES
// ─────────────────────────────────────────────
function normalizeName(name) {
  return name
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z\s]/g, "")
    .replace(/\s+/g, " ")
    .trim();
}

function namesMatch(pickName, espnName) {
  const np = normalizeName(pickName);
  const ne = normalizeName(espnName);
  if (np === ne) return true;
  // last-name + first-initial fallback
  const plast = np.split(" ").slice(-1)[0];
  const elast = ne.split(" ").slice(-1)[0];
  if (plast.length > 3 && plast === elast) {
    return np.split(" ")[0][0] === ne.split(" ")[0][0];
  }
  return false;
}

function fmt(score) {
  if (score === null || score === undefined) return "–";
  if (score === 0) return "E";
  return score > 0 ? `+${score}` : `${score}`;
}

function scoreColor(score) {
  if (score === null || score === undefined) return "#6a8a72";
  if (score <= -2) return "#2aaa5a";
  if (score === -1) return "#4cca7a";
  if (score === 0) return "#f0ebe0";
  if (score === 1) return "#e8a060";
  return "#e05a48";
}

// ─────────────────────────────────────────────
// ESPN API
// ─────────────────────────────────────────────
async function fetchLeaderboard() {
  const res = await fetch(
    "https://site.api.espn.com/apis/site/v2/sports/golf/leaderboard?league=pga",
    { cache: "no-store" }
  );
  if (!res.ok) throw new Error(`ESPN API error: ${res.status}`);
  const data = await res.json();

  const event = data.events?.[0];
  if (!event) throw new Error("No event data returned");

  const comp = event.competitions?.[0];
  const competitors = comp?.competitors || [];
  const currentRound = comp?.status?.period || 0;

  const golfers = competitors.map((c) => {
    const linescores = c.linescores || [];
    const roundScores = linescores.map((ls) => {
      const raw = parseFloat(ls.value);
      return isNaN(raw) ? null : raw - AUGUSTA_PAR;
    });

    const scoreStr = (c.score || "E").replace(/^\+/, "");
    const totalToPar =
      scoreStr === "E" || scoreStr === "0"
        ? 0
        : parseInt(scoreStr, 10) || 0;

    const statusName = c.status?.type?.name || "";
    const madecut = !(
      statusName.includes("CUT") ||
      statusName.includes("WD") ||
      statusName.includes("DQ")
    );

    return {
      name: c.athlete?.displayName || "",
      totalToPar,
      roundScores,
      madecut,
      position: c.status?.displayValue || "",
      statusName,
    };
  });

  return {
    golfers,
    currentRound,
    isWeekend: currentRound >= 3,
    eventName: event.shortName || event.name || "Masters Tournament",
  };
}

// ─────────────────────────────────────────────
// SCORING ENGINE
// ─────────────────────────────────────────────
function findGolfer(name, golfers) {
  return golfers.find((g) => namesMatch(name, g.name)) || null;
}

function calcTeam(participant, golfers, currentRound, isWeekend) {
  const enriched = participant.golfers.map((p) => ({
    ...p,
    live: findGolfer(p.name, golfers),
  }));

  let total = 0;
  let thuScore = null;
  let friScore = null;
  let weekendScore = null;
  let bonusScore = 0;
  const bonusHits = { missCut: false, makeCut: false };

  // Thursday – best 4 daily round 1 scores
  if (currentRound >= 1) {
    const scores = enriched
      .map((g) => g.live?.roundScores?.[0] ?? null)
      .filter((s) => s !== null)
      .sort((a, b) => a - b)
      .slice(0, 4);
    if (scores.length) {
      thuScore = scores.reduce((s, v) => s + v, 0);
      total += thuScore;
    }
  }

  // Friday – best 4 daily round 2 scores
  if (currentRound >= 2) {
    const scores = enriched
      .map((g) => g.live?.roundScores?.[1] ?? null)
      .filter((s) => s !== null)
      .sort((a, b) => a - b)
      .slice(0, 4);
    if (scores.length) {
      friScore = scores.reduce((s, v) => s + v, 0);
      total += friScore;
    }
  }

  // Weekend – best 3 cumulative totals
  if (isWeekend) {
    const scores = enriched
      .map((g) => g.live?.totalToPar ?? null)
      .filter((s) => s !== null)
      .sort((a, b) => a - b)
      .slice(0, 3);
    if (scores.length) {
      weekendScore = scores.reduce((s, v) => s + v, 0);
      total += weekendScore;
    }

    if (participant.bonusMissCut) {
      const g = findGolfer(participant.bonusMissCut, golfers);
      if (g && !g.madecut) {
        bonusScore -= 3;
        total -= 3;
        bonusHits.missCut = true;
      }
    }
    if (participant.bonusMakeCut) {
      const g = findGolfer(participant.bonusMakeCut, golfers);
      if (g && g.madecut) {
        bonusScore -= 3;
        total -= 3;
        bonusHits.makeCut = true;
      }
    }
  }

  return { total, thuScore, friScore, weekendScore, bonusScore, bonusHits, enriched };
}

// ─────────────────────────────────────────────
// STYLES (inline, no Tailwind needed)
// ─────────────────────────────────────────────
const S = {
  app: {
    minHeight: "100vh",
    background: "linear-gradient(160deg, #0a1f10 0%, #0f2a16 50%, #0a1a0d 100%)",
    fontFamily: "'DM Sans', sans-serif",
    color: "#f0ebe0",
  },
  header: {
    borderBottom: "1px solid rgba(201,168,76,0.25)",
    background: "rgba(10,20,12,0.6)",
    backdropFilter: "blur(8px)",
    position: "sticky",
    top: 0,
    zIndex: 100,
    padding: "0 1.5rem",
  },
  headerInner: {
    maxWidth: 960,
    margin: "0 auto",
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    padding: "1rem 0",
    gap: "1rem",
    flexWrap: "wrap",
  },
  logo: {
    display: "flex",
    flexDirection: "column",
    gap: 2,
  },
  logoTitle: {
    fontFamily: "'Playfair Display', serif",
    fontSize: "clamp(1.2rem, 3vw, 1.6rem)",
    fontWeight: 700,
    color: "#c9a84c",
    letterSpacing: "0.03em",
    lineHeight: 1.1,
  },
  logoSub: {
    fontSize: "0.72rem",
    color: "#6a8a72",
    letterSpacing: "0.15em",
    textTransform: "uppercase",
    fontWeight: 500,
  },
  statusPill: {
    display: "flex",
    alignItems: "center",
    gap: 6,
    background: "rgba(201,168,76,0.1)",
    border: "1px solid rgba(201,168,76,0.25)",
    borderRadius: 100,
    padding: "4px 12px",
    fontSize: "0.72rem",
    color: "#c9a84c",
    letterSpacing: "0.05em",
    textTransform: "uppercase",
    fontWeight: 500,
    whiteSpace: "nowrap",
  },
  dot: (live) => ({
    width: 6,
    height: 6,
    borderRadius: "50%",
    background: live ? "#4cca7a" : "#c9a84c",
    boxShadow: live ? "0 0 6px #4cca7a" : "none",
    animation: live ? "pulse 2s infinite" : "none",
  }),
  tabs: {
    display: "flex",
    gap: 4,
    background: "rgba(0,0,0,0.2)",
    border: "1px solid rgba(201,168,76,0.15)",
    borderRadius: 12,
    padding: 4,
  },
  tab: (active) => ({
    padding: "6px 16px",
    borderRadius: 8,
    border: "none",
    background: active ? "rgba(201,168,76,0.18)" : "transparent",
    color: active ? "#c9a84c" : "#6a8a72",
    fontSize: "0.8rem",
    fontWeight: 600,
    cursor: "pointer",
    transition: "all 0.15s",
    fontFamily: "'DM Sans', sans-serif",
    letterSpacing: "0.03em",
    whiteSpace: "nowrap",
  }),
  main: {
    maxWidth: 960,
    margin: "0 auto",
    padding: "1.5rem",
  },
  card: {
    background: "rgba(255,255,255,0.03)",
    border: "1px solid rgba(255,255,255,0.07)",
    borderRadius: 16,
    overflow: "hidden",
  },
  tableHeader: {
    display: "grid",
    padding: "0.75rem 1.25rem",
    background: "rgba(201,168,76,0.07)",
    borderBottom: "1px solid rgba(201,168,76,0.12)",
    fontSize: "0.7rem",
    fontWeight: 600,
    letterSpacing: "0.12em",
    textTransform: "uppercase",
    color: "#c9a84c",
    gap: "0.5rem",
  },
  row: (rank) => ({
    display: "grid",
    padding: "0.9rem 1.25rem",
    borderBottom: "1px solid rgba(255,255,255,0.05)",
    alignItems: "center",
    gap: "0.5rem",
    transition: "background 0.15s",
    background: rank === 1 ? "rgba(201,168,76,0.06)" : "transparent",
    cursor: "pointer",
  }),
};

// ─────────────────────────────────────────────
// RANK BADGE
// ─────────────────────────────────────────────
function RankBadge({ rank }) {
  const medals = { 1: "🥇", 2: "🥈", 3: "🥉" };
  if (medals[rank])
    return <span style={{ fontSize: "1.1rem" }}>{medals[rank]}</span>;
  return (
    <span style={{ fontSize: "0.85rem", color: "#6a8a72", fontWeight: 600 }}>
      {rank}
    </span>
  );
}

// ─────────────────────────────────────────────
// SCORE CELL
// ─────────────────────────────────────────────
function Score({ value, style = {} }) {
  if (value === null || value === undefined)
    return <span style={{ color: "#3a5a42", ...style }}>–</span>;
  return (
    <span style={{ color: scoreColor(value), fontWeight: 600, ...style }}>
      {fmt(value)}
    </span>
  );
}

// ─────────────────────────────────────────────
// TIER BADGE
// ─────────────────────────────────────────────
const TIER_STYLE = {
  A: { bg: "rgba(201,168,76,0.15)", color: "#c9a84c" },
  B: { bg: "rgba(100,180,180,0.15)", color: "#7ed4d0" },
  C: { bg: "rgba(180,120,200,0.15)", color: "#c48ed8" },
  D: { bg: "rgba(100,190,120,0.15)", color: "#7acf94" },
  E: { bg: "rgba(200,110,100,0.15)", color: "#d48878" },
};

function TierBadge({ tier }) {
  const ts = TIER_STYLE[tier] || {};
  return (
    <span
      style={{
        background: ts.bg,
        color: ts.color,
        borderRadius: 5,
        padding: "1px 6px",
        fontSize: "0.68rem",
        fontWeight: 700,
        letterSpacing: "0.08em",
        flexShrink: 0,
      }}
    >
      {tier}
    </span>
  );
}

// ─────────────────────────────────────────────
// LEADERBOARD TAB
// ─────────────────────────────────────────────
function Leaderboard({ teams, currentRound, isWeekend }) {
  const [expanded, setExpanded] = useState(null);
  const cols = isWeekend
    ? "28px 1fr 80px 64px 64px 80px 56px"
    : "28px 1fr 80px 64px 64px 64px";

  const headerCols = isWeekend
    ? ["", "Player", "Total", "Thu", "Fri", "Wknd", "Bonus"]
    : ["", "Player", "Total", "Thu", "Fri", "Thru"];

  return (
    <div>
      <div style={{ marginBottom: "1rem" }}>
        <h2
          style={{
            fontFamily: "'Playfair Display', serif",
            fontSize: "1.4rem",
            color: "#c9a84c",
            marginBottom: 4,
          }}
        >
          Pool Leaderboard
        </h2>
        <p style={{ fontSize: "0.78rem", color: "#6a8a72" }}>
          {currentRound === 0
            ? "Tournament hasn't started yet — check back Thursday."
            : isWeekend
            ? "Weekend: Best 3 cumulative scores + best 4 daily Thu & Fri"
            : `Round ${currentRound}: Best 4 daily scores each round`}
        </p>
      </div>

      <div style={S.card}>
        <div style={{ ...S.tableHeader, gridTemplateColumns: cols }}>
          {headerCols.map((h, i) => (
            <span key={i} style={{ textAlign: i > 1 ? "center" : "left" }}>
              {h}
            </span>
          ))}
        </div>

        {teams.map((team, idx) => {
          const isOpen = expanded === team.id;
          return (
            <div key={team.id}>
              {/* Main row */}
              <div
                style={{
                  ...S.row(idx + 1),
                  gridTemplateColumns: cols,
                  background: isOpen
                    ? "rgba(201,168,76,0.08)"
                    : idx === 0
                    ? "rgba(201,168,76,0.05)"
                    : "transparent",
                }}
                onClick={() => setExpanded(isOpen ? null : team.id)}
              >
                <RankBadge rank={idx + 1} />
                <div>
                  <div style={{ fontWeight: 600, fontSize: "0.95rem" }}>
                    {team.name}
                  </div>
                  {isWeekend && team.bonusScore !== 0 && (
                    <div style={{ fontSize: "0.68rem", color: "#4cca7a", marginTop: 1 }}>
                      {team.bonusHits.missCut && "✓ Miss Cut "}
                      {team.bonusHits.makeCut && "✓ Make Cut"}
                    </div>
                  )}
                </div>

                {/* Total */}
                <div style={{ textAlign: "center" }}>
                  <Score
                    value={currentRound === 0 ? null : team.total}
                    style={{ fontSize: "1.05rem" }}
                  />
                </div>

                {/* Thu */}
                <Score
                  value={team.thuScore}
                  style={{ textAlign: "center", display: "block" }}
                />

                {/* Fri */}
                <Score
                  value={team.friScore}
                  style={{ textAlign: "center", display: "block" }}
                />

                {/* Weekend or Thru */}
                {isWeekend ? (
                  <Score
                    value={team.weekendScore}
                    style={{ textAlign: "center", display: "block" }}
                  />
                ) : (
                  <span
                    style={{
                      textAlign: "center",
                      display: "block",
                      fontSize: "0.8rem",
                      color: "#6a8a72",
                    }}
                  >
                    {currentRound > 0 ? `R${currentRound}` : "–"}
                  </span>
                )}

                {/* Bonus */}
                {isWeekend && (
                  <Score
                    value={team.bonusScore === 0 ? null : team.bonusScore}
                    style={{ textAlign: "center", display: "block" }}
                  />
                )}
              </div>

              {/* Expanded picks */}
              {isOpen && (
                <div
                  style={{
                    background: "rgba(0,0,0,0.2)",
                    borderBottom: "1px solid rgba(255,255,255,0.05)",
                    padding: "0.75rem 1.25rem 1rem",
                  }}
                >
                  <div
                    style={{
                      display: "grid",
                      gridTemplateColumns: "repeat(auto-fill, minmax(240px, 1fr))",
                      gap: "0.5rem",
                    }}
                  >
                    {team.enriched.map((g, i) => {
                      const r1 = g.live?.roundScores?.[0];
                      const r2 = g.live?.roundScores?.[1];
                      const r3 = g.live?.roundScores?.[2];
                      const r4 = g.live?.roundScores?.[3];
                      const total = g.live?.totalToPar;
                      const cut = g.live?.madecut;
                      return (
                        <div
                          key={i}
                          style={{
                            display: "flex",
                            alignItems: "center",
                            gap: 10,
                            padding: "0.5rem 0.75rem",
                            background: "rgba(255,255,255,0.03)",
                            borderRadius: 10,
                            border: `1px solid ${
                              cut === false
                                ? "rgba(224,90,72,0.2)"
                                : "rgba(255,255,255,0.06)"
                            }`,
                          }}
                        >
                          <TierBadge tier={g.tier} />
                          <div style={{ flex: 1, minWidth: 0 }}>
                            <div
                              style={{
                                fontSize: "0.85rem",
                                fontWeight: 500,
                                whiteSpace: "nowrap",
                                overflow: "hidden",
                                textOverflow: "ellipsis",
                                color:
                                  cut === false ? "#e05a48" : "#f0ebe0",
                              }}
                            >
                              {g.name}
                              {cut === false && (
                                <span
                                  style={{
                                    marginLeft: 5,
                                    fontSize: "0.65rem",
                                    color: "#e05a48",
                                    background: "rgba(224,90,72,0.12)",
                                    padding: "1px 5px",
                                    borderRadius: 4,
                                  }}
                                >
                                  CUT
                                </span>
                              )}
                            </div>
                            <div
                              style={{
                                display: "flex",
                                gap: 8,
                                marginTop: 2,
                                fontSize: "0.72rem",
                              }}
                            >
                              {[r1, r2, r3, r4].map((rs, ri) =>
                                rs !== null && rs !== undefined ? (
                                  <span key={ri} style={{ color: scoreColor(rs) }}>
                                    R{ri + 1}: {fmt(rs)}
                                  </span>
                                ) : null
                              )}
                            </div>
                          </div>
                          <Score value={total} style={{ fontSize: "0.9rem", flexShrink: 0 }} />
                        </div>
                      );
                    })}
                  </div>

                  {/* Bonus picks */}
                  <div
                    style={{
                      marginTop: "0.75rem",
                      display: "flex",
                      gap: "0.5rem",
                      flexWrap: "wrap",
                    }}
                  >
                    {team.bonusMissCut && (
                      <BonusPill
                        label="Miss Cut"
                        golfer={team.bonusMissCut}
                        hit={team.bonusHits.missCut}
                        isWeekend={isWeekend}
                      />
                    )}
                    {team.bonusMakeCut && (
                      <BonusPill
                        label="Make Cut"
                        golfer={team.bonusMakeCut}
                        hit={team.bonusHits.makeCut}
                        isWeekend={isWeekend}
                      />
                    )}
                    {!team.bonusMissCut && !team.bonusMakeCut && (
                      <span style={{ fontSize: "0.72rem", color: "#3a5a42" }}>
                        No bonus picks
                      </span>
                    )}
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}

function BonusPill({ label, golfer, hit, isWeekend }) {
  const pending = !isWeekend;
  return (
    <div
      style={{
        display: "flex",
        alignItems: "center",
        gap: 6,
        padding: "4px 10px",
        borderRadius: 100,
        fontSize: "0.7rem",
        fontWeight: 500,
        background: pending
          ? "rgba(255,255,255,0.05)"
          : hit
          ? "rgba(76,202,122,0.12)"
          : "rgba(224,90,72,0.1)",
        border: `1px solid ${
          pending
            ? "rgba(255,255,255,0.1)"
            : hit
            ? "rgba(76,202,122,0.3)"
            : "rgba(224,90,72,0.25)"
        }`,
        color: pending ? "#6a8a72" : hit ? "#4cca7a" : "#e05a48",
      }}
    >
      <span style={{ opacity: 0.7 }}>{label}:</span>
      <span>{golfer}</span>
      {!pending && (
        <span style={{ fontWeight: 700 }}>{hit ? "✓ −3" : "✗"}</span>
      )}
      {pending && <span style={{ opacity: 0.5 }}>• pending</span>}
    </div>
  );
}

// ─────────────────────────────────────────────
// FIELD TAB (live Masters leaderboard)
// ─────────────────────────────────────────────
function Field({ golfers, currentRound }) {
  // Find which golfers are in someone's pool
  const allPickedNames = PARTICIPANTS.flatMap((p) =>
    p.golfers.map((g) => g.name)
  );
  const isInPool = (name) =>
    allPickedNames.some((n) => namesMatch(n, name));

  const active = golfers.filter((g) => g.madecut);
  const cut = golfers.filter((g) => !g.madecut);

  const colTemplate = "56px 1fr 64px 64px 64px 64px 72px";

  const GolferRow = ({ g, dimmed }) => {
    const inPool = isInPool(g.name);
    return (
      <div
        style={{
          display: "grid",
          gridTemplateColumns: colTemplate,
          padding: "0.65rem 1.25rem",
          borderBottom: "1px solid rgba(255,255,255,0.04)",
          alignItems: "center",
          gap: "0.5rem",
          opacity: dimmed ? 0.45 : 1,
          background: inPool
            ? "rgba(201,168,76,0.04)"
            : "transparent",
        }}
      >
        <span style={{ color: "#6a8a72", fontSize: "0.8rem" }}>
          {g.position}
        </span>
        <span style={{ fontSize: "0.85rem", fontWeight: inPool ? 600 : 400 }}>
          {g.name}
          {inPool && (
            <span
              style={{
                marginLeft: 6,
                fontSize: "0.6rem",
                color: "#c9a84c",
                opacity: 0.7,
              }}
            >
              ★
            </span>
          )}
        </span>
        {[0, 1, 2, 3].map((ri) => (
          <Score
            key={ri}
            value={g.roundScores?.[ri] ?? null}
            style={{ textAlign: "center", display: "block", fontSize: "0.8rem" }}
          />
        ))}
        <Score
          value={g.totalToPar}
          style={{ textAlign: "center", display: "block" }}
        />
      </div>
    );
  };

  return (
    <div>
      <div style={{ marginBottom: "1rem" }}>
        <h2
          style={{
            fontFamily: "'Playfair Display', serif",
            fontSize: "1.4rem",
            color: "#c9a84c",
            marginBottom: 4,
          }}
        >
          Masters Field
        </h2>
        <p style={{ fontSize: "0.78rem", color: "#6a8a72" }}>
          ★ = picked by someone in the pool
        </p>
      </div>
      <div style={S.card}>
        <div
          style={{
            ...S.tableHeader,
            gridTemplateColumns: colTemplate,
          }}
        >
          {["Pos", "Golfer", "R1", "R2", "R3", "R4", "Total"].map(
            (h, i) => (
              <span key={i} style={{ textAlign: i > 1 ? "center" : "left" }}>
                {h}
              </span>
            )
          )}
        </div>
        {active.map((g) => (
          <GolferRow key={g.name} g={g} dimmed={false} />
        ))}
        {cut.length > 0 && (
          <>
            <div
              style={{
                padding: "0.4rem 1.25rem",
                fontSize: "0.68rem",
                letterSpacing: "0.12em",
                textTransform: "uppercase",
                color: "#e05a48",
                background: "rgba(224,90,72,0.06)",
                borderBottom: "1px solid rgba(224,90,72,0.1)",
              }}
            >
              — Missed Cut / WD —
            </div>
            {cut.map((g) => (
              <GolferRow key={g.name} g={g} dimmed={true} />
            ))}
          </>
        )}
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────
// PICKS TAB
// ─────────────────────────────────────────────
function Picks({ teams }) {
  return (
    <div>
      <div style={{ marginBottom: "1rem" }}>
        <h2
          style={{
            fontFamily: "'Playfair Display', serif",
            fontSize: "1.4rem",
            color: "#c9a84c",
            marginBottom: 4,
          }}
        >
          All Picks
        </h2>
        <p style={{ fontSize: "0.78rem", color: "#6a8a72" }}>
          Every participant's roster and bonus picks
        </p>
      </div>
      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))",
          gap: "1rem",
        }}
      >
        {teams.map((team) => (
          <div key={team.id} style={{ ...S.card, padding: "1.1rem" }}>
            <div
              style={{
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
                marginBottom: "0.75rem",
              }}
            >
              <div
                style={{
                  fontFamily: "'Playfair Display', serif",
                  fontSize: "1rem",
                  fontWeight: 600,
                  color: "#e8d08a",
                }}
              >
                {team.name}
              </div>
              {team.total !== undefined && (
                <Score value={team.total} style={{ fontSize: "1rem" }} />
              )}
            </div>

            <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
              {team.enriched.map((g, i) => (
                <div
                  key={i}
                  style={{
                    display: "flex",
                    alignItems: "center",
                    gap: 8,
                    padding: "0.4rem 0.6rem",
                    borderRadius: 8,
                    background: "rgba(255,255,255,0.03)",
                    border: `1px solid ${
                      g.live?.madecut === false
                        ? "rgba(224,90,72,0.15)"
                        : "rgba(255,255,255,0.05)"
                    }`,
                  }}
                >
                  <TierBadge tier={g.tier} />
                  <span
                    style={{
                      flex: 1,
                      fontSize: "0.83rem",
                      color:
                        g.live?.madecut === false ? "#e05a48" : "#f0ebe0",
                    }}
                  >
                    {g.name}
                  </span>
                  {g.live?.madecut === false && (
                    <span
                      style={{
                        fontSize: "0.6rem",
                        color: "#e05a48",
                        background: "rgba(224,90,72,0.1)",
                        padding: "1px 5px",
                        borderRadius: 4,
                        fontWeight: 600,
                      }}
                    >
                      CUT
                    </span>
                  )}
                  <Score
                    value={g.live?.totalToPar ?? null}
                    style={{ fontSize: "0.82rem" }}
                  />
                </div>
              ))}
            </div>

            <div
              style={{
                marginTop: "0.75rem",
                paddingTop: "0.6rem",
                borderTop: "1px solid rgba(255,255,255,0.06)",
                display: "flex",
                flexDirection: "column",
                gap: 4,
              }}
            >
              {team.bonusMissCut ? (
                <div
                  style={{
                    fontSize: "0.72rem",
                    color: "#6a8a72",
                    display: "flex",
                    justifyContent: "space-between",
                  }}
                >
                  <span>🎯 Miss cut:</span>
                  <span style={{ color: "#a8c4b0" }}>{team.bonusMissCut}</span>
                </div>
              ) : null}
              {team.bonusMakeCut ? (
                <div
                  style={{
                    fontSize: "0.72rem",
                    color: "#6a8a72",
                    display: "flex",
                    justifyContent: "space-between",
                  }}
                >
                  <span>🎯 Make cut:</span>
                  <span style={{ color: "#a8c4b0" }}>{team.bonusMakeCut}</span>
                </div>
              ) : null}
              {!team.bonusMissCut && !team.bonusMakeCut && (
                <div style={{ fontSize: "0.72rem", color: "#3a5a42" }}>
                  No bonus picks
                </div>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────
// RULES TAB
// ─────────────────────────────────────────────
function Rules() {
  return (
    <div>
      <div style={{ marginBottom: "1rem" }}>
        <h2
          style={{
            fontFamily: "'Playfair Display', serif",
            fontSize: "1.4rem",
            color: "#c9a84c",
            marginBottom: 4,
          }}
        >
          How It Works
        </h2>
      </div>
      <div style={{ display: "flex", flexDirection: "column", gap: "1rem" }}>
        {[
          {
            icon: "🏌️",
            title: "Team Structure",
            body: "Each participant picks 6 golfers: 2 from Tier A, 1 each from Tiers B, C, D, and E.",
          },
          {
            icon: "📅",
            title: "Thursday & Friday",
            body: "Your best 4 of 6 golfers' score for that day count. Only the single-day score matters — not the cumulative total.",
          },
          {
            icon: "🏆",
            title: "Saturday & Sunday",
            body: "Scoring switches to your best 3 golfers' cumulative tournament total (all rounds combined, lowest 3 of your 6).",
          },
          {
            icon: "🎯",
            title: "Bonus: Miss the Cut (−3)",
            body: "Before the tournament, each participant picks one Tier B golfer (separate from their team) who they think will miss the cut. Correct = −3 strokes off your total.",
          },
          {
            icon: "🎯",
            title: "Bonus: Make the Cut (−3)",
            body: "Pick one Tier E golfer to make the cut. Correct = −3 strokes. Bonuses activate from Saturday onward.",
          },
          {
            icon: "📊",
            title: "Final Score",
            body: "Lowest score wins. Thu daily best 4 + Fri daily best 4 + Weekend best 3 cumulative + bonuses = your total.",
          },
        ].map((r) => (
          <div
            key={r.title}
            style={{
              ...S.card,
              padding: "1rem 1.25rem",
              display: "flex",
              gap: "1rem",
              alignItems: "flex-start",
            }}
          >
            <span style={{ fontSize: "1.4rem", flexShrink: 0 }}>{r.icon}</span>
            <div>
              <div
                style={{
                  fontWeight: 600,
                  color: "#c9a84c",
                  marginBottom: 4,
                  fontSize: "0.9rem",
                }}
              >
                {r.title}
              </div>
              <div style={{ fontSize: "0.85rem", color: "#a8c4b0", lineHeight: 1.5 }}>
                {r.body}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────
// ROOT APP
// ─────────────────────────────────────────────
export default function App() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [tab, setTab] = useState("leaderboard");
  const [lastUpdated, setLastUpdated] = useState(null);

  const load = useCallback(async () => {
    try {
      const d = await fetchLeaderboard();
      setData(d);
      setLastUpdated(new Date());
      setError(null);
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
    const iv = setInterval(load, 60_000);
    return () => clearInterval(iv);
  }, [load]);

  // Build ranked team scores
  const teams = data
    ? PARTICIPANTS.map((p) => {
        const result = calcTeam(
          p,
          data.golfers,
          data.currentRound,
          data.isWeekend
        );
        return { ...p, ...result };
      }).sort((a, b) => a.total - b.total)
    : PARTICIPANTS.map((p) => ({
        ...p,
        total: null,
        thuScore: null,
        friScore: null,
        weekendScore: null,
        bonusScore: 0,
        bonusHits: { missCut: false, makeCut: false },
        enriched: p.golfers.map((g) => ({ ...g, live: null })),
      }));

  const TABS = [
    { id: "leaderboard", label: "Leaderboard" },
    { id: "field", label: "Field" },
    { id: "picks", label: "Picks" },
    { id: "rules", label: "Rules" },
  ];

  const isLive =
    data?.currentRound > 0 && !error;

  return (
    <div style={S.app}>
      {/* Pulse animation */}
      <style>{`
        @keyframes pulse {
          0%, 100% { opacity: 1; }
          50% { opacity: 0.4; }
        }
        @keyframes spin {
          to { transform: rotate(360deg); }
        }
      `}</style>

      {/* Header */}
      <header style={S.header}>
        <div style={S.headerInner}>
          <div style={S.logo}>
            <div style={S.logoTitle}>⛳ The Masters Pool</div>
            <div style={S.logoSub}>Augusta National · 2026</div>
          </div>

          <div style={{ display: "flex", alignItems: "center", gap: "0.75rem", flexWrap: "wrap" }}>
            <div style={S.statusPill}>
              <div style={S.dot(isLive && !error)} />
              {loading
                ? "Loading..."
                : error
                ? "Data unavailable"
                : data?.currentRound === 0
                ? "Pre-tournament"
                : data?.isWeekend
                ? `Weekend · R${data.currentRound}`
                : `Round ${data.currentRound}`}
            </div>

            {lastUpdated && (
              <div
                style={{
                  fontSize: "0.65rem",
                  color: "#3a5a42",
                  whiteSpace: "nowrap",
                }}
              >
                Updated {lastUpdated.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
              </div>
            )}
          </div>
        </div>

        {/* Tabs */}
        <div style={{ maxWidth: 960, margin: "0 auto", paddingBottom: "0.75rem" }}>
          <div style={S.tabs}>
            {TABS.map((t) => (
              <button
                key={t.id}
                style={S.tab(tab === t.id)}
                onClick={() => setTab(t.id)}
              >
                {t.label}
              </button>
            ))}
          </div>
        </div>
      </header>

      {/* Content */}
      <main style={S.main}>
        {error && (
          <div
            style={{
              background: "rgba(224,90,72,0.1)",
              border: "1px solid rgba(224,90,72,0.25)",
              borderRadius: 12,
              padding: "0.75rem 1rem",
              marginBottom: "1rem",
              fontSize: "0.8rem",
              color: "#e05a48",
            }}
          >
            ⚠️ Couldn't load live data: {error}. Scores will refresh automatically.
          </div>
        )}

        {tab === "leaderboard" && (
          <Leaderboard
            teams={teams}
            currentRound={data?.currentRound || 0}
            isWeekend={data?.isWeekend || false}
          />
        )}
        {tab === "field" && (
          <Field
            golfers={data?.golfers || []}
            currentRound={data?.currentRound || 0}
          />
        )}
        {tab === "picks" && <Picks teams={teams} />}
        {tab === "rules" && <Rules />}
      </main>

      {/* Footer */}
      <footer
        style={{
          textAlign: "center",
          padding: "2rem",
          fontSize: "0.7rem",
          color: "#3a5a42",
          borderTop: "1px solid rgba(255,255,255,0.04)",
          marginTop: "2rem",
        }}
      >
        Live data via ESPN · Refreshes every 60s · Built with ⛳
      </footer>
    </div>
  );
}
